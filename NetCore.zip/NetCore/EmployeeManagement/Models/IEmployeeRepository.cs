﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EmployeeManagement.Models
{
    public interface IEmployeeRepository
    {
        /// <summary>
        /// Get employee details
        /// </summary>
        /// <param name="id">Get filter data based on id</param>
        /// <returns>Return the employee details</returns>
        Employee GetEmployee(int id);
       
        /// <summary>
        /// Get All employee list
        /// </summary>
        /// <returns>Return Employee list</returns>
        IEnumerable<Employee> GetAllEmployee();

        /// <summary>
        /// Add new employee record
        /// </summary>
        /// <param name="employee">New employee information</param>
        /// <returns>return employee record</returns>
        Employee Add(Employee employee);

        /// <summary>
        /// Update the employee
        /// </summary>
        /// <param name="employee">Employee information available in employee parameter</param>
        /// <returns>Return the updated employee information</returns>
        Employee Update(Employee employee);

        /// <summary>
        /// Delete the employee that match with given Id
        /// </summary>
        /// <param name="Id">Id value that need to delete</param>
        /// <returns>Return deleted employee</returns>
        Employee Delete(int Id);
    }
}
